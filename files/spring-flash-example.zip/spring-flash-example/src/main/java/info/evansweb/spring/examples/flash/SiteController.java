package info.evansweb.spring.examples.flash;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * Copyright 2007 Jon Evans, jon@springyweb.com
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 * 
 * @author Jon Evans, jon@springyweb.com
 *
 */
@Controller
public class SiteController {
	
	@Autowired
	private Flash flash;
	
	@RequestMapping("/home.do")
	public void home() {
		
	}

	@RequestMapping("/setnotice.do")
	public ModelAndView setNotice(@RequestParam(value="ttl",required=false) String ttl) {
		setFlash("notice", ttl);
		
		ModelAndView mav = new ModelAndView("redirect:/home.do");
		return mav;
	}
	@RequestMapping("/seterror.do")
	public ModelAndView setError(@RequestParam(value="ttl",required=false) String ttl) {
		setFlash("error", ttl);
		
		ModelAndView mav = new ModelAndView("redirect:/home.do");
		return mav;
	}
	
	private void setFlash(String type, String ttlStr) {
		int ttl = 2; // default ttl is 2
		if (ttlStr != null) {
			ttl = Integer.parseInt(ttlStr);
		}
		flash.set(type, "This is a message of type " + type + " with a ttl of " + ttl, ttl);
	}
}
